﻿#if UNITY_EDITOR
using System;
using System.IO;
using System.Text;
using System.Data;
using System.Linq;
using System.Globalization;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using ExcelDataReader; // ExcelDataReader.dll + ExcelDataReader.DataSet.dll (put under Assets/Plugins/Editor/)

public class XlsxToJsonAndRegistry : EditorWindow
{
    private const string XlsxFolderPath = "Assets/Spreadsheets";
    private const string JsonOutFolder = "Assets/Resources/CSVDataJson";
    private const string OutputScriptPath = "Assets/Scripts/Generated";

    private const string RegistryFilePath = OutputScriptPath + "/GameDataRegistry.cs";
    private const string StatEnumFilePath = OutputScriptPath + "/StatType.cs";

    [MenuItem("Tools/Generate (XLSX→JSON + Classes + Registry)")]
    public static void GenerateAll()
    {
        Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
        System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);

        if (!Directory.Exists(OutputScriptPath)) Directory.CreateDirectory(OutputScriptPath);
        if (!Directory.Exists(JsonOutFolder)) Directory.CreateDirectory(JsonOutFolder);
        if (!Directory.Exists(XlsxFolderPath)) { Debug.LogError($"[Gen] Not found: {XlsxFolderPath}"); return; }

        var metas = new List<CsvMeta>();
        var statTypeValues = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        foreach (var xlsx in Directory.GetFiles(XlsxFolderPath, "*.xlsx", SearchOption.TopDirectoryOnly))
        {
            using var fs = File.Open(xlsx, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
            using var reader = ExcelReaderFactory.CreateReader(fs);

            var conf = new ExcelDataSetConfiguration
            {
                ConfigureDataTable = _ => new ExcelDataTableConfiguration { UseHeaderRow = true }
            };
            var ds = reader.AsDataSet(conf);
            if (ds == null || ds.Tables.Count == 0)
            {
                Debug.LogWarning($"[Gen] No sheets in {xlsx}");
                continue;
            }

            string fileName = Path.GetFileNameWithoutExtension(xlsx);
            var table = PickBestTable(ds, fileName);
            if (table == null || table.Columns.Count == 0 || table.Rows.Count == 0)
            {
                Debug.LogWarning($"[Gen] Empty or no table in {xlsx}");
                continue;
            }

            // headers
            string[] headers = new string[table.Columns.Count];
            for (int c = 0; c < table.Columns.Count; c++)
                headers[c] = Clean(table.Columns[c].ColumnName);

            // type inference (no hard rules; only if column is consistently numeric/bool)
            var fieldTypes = new string[headers.Length];
            for (int c = 0; c < headers.Length; c++)
            {
                string h = headers[c];
                if (EqualsIgnoreCase(h, "statType"))
                {
                    fieldTypes[c] = "StatType";
                    continue;
                }
                fieldTypes[c] = DecideTypeForColumn(table, c);
            }

            // enum value collection
            int statIdx = IndexOfIgnoreCase(headers, "statType");
            if (statIdx >= 0)
            {
                foreach (DataRow row in table.Rows)
                {
                    var raw = row[statIdx]?.ToString();
                    raw = Clean(raw);
                    if (!string.IsNullOrEmpty(raw)) statTypeValues.Add(raw);
                }
            }

            // JSON out (empty -> "", keep strings verbatim)
            string jsonOut = Path.Combine(JsonOutFolder, fileName + ".json");
            WriteJsonFromDataTable(jsonOut, table, headers);

            metas.Add(new CsvMeta
            {
                FileName = fileName,
                Headers = headers,
                FieldTypes = fieldTypes
            });

            Debug.Log($"[Gen] Wrote JSON: {jsonOut} (rows: {table.Rows.Count})");
        }

        GenerateStatTypeEnum(statTypeValues);
        foreach (var m in metas) GenerateRowClass(m);
        GenerateRegistry(metas);

        AssetDatabase.Refresh();
        Debug.Log("✅ XLSX→JSON/Classes/Registry 생성 완료");
    }

    // ─────────────────────────────────────────────────────────────
    // Pick best sheet (so Icon/ID/Name/Desc headers are captured)
    // ─────────────────────────────────────────────────────────────
    private static DataTable PickBestTable(DataSet ds, string fileName)
    {
        if (ds == null || ds.Tables.Count == 0) return null;
        string[] want = { "Icon", "ID", "Name", "Desc" };

        DataTable best = null;
        int bestScore = int.MinValue;

        foreach (DataTable t in ds.Tables)
        {
            if (t.Columns.Count == 0) continue;

            int score = 0;
            for (int c = 0; c < t.Columns.Count; c++)
            {
                string h = Clean(t.Columns[c].ColumnName);
                foreach (var w in want)
                    if (string.Equals(h, w, StringComparison.OrdinalIgnoreCase))
                        score++;
            }
            // slight bias toward more columns (more data)
            score += t.Columns.Count / 10;

            if (score > bestScore)
            {
                best = t;
                bestScore = score;
            }
        }

        if (best != null)
        {
            var headers = Enumerable.Range(0, best.Columns.Count)
                .Select(ci => Clean(best.Columns[ci].ColumnName))
                .ToArray();
            Debug.Log($"[Gen] Picked sheet for {fileName}: \"{best.TableName}\"  headers=[{string.Join(", ", headers)}]");
        }
        else
        {
            Debug.LogWarning($"[Gen] No suitable sheet found in {fileName}");
        }
        return best ?? ds.Tables[0];
    }

    // ─────────────────────────────────────────────────────────────
    // meta
    // ─────────────────────────────────────────────────────────────
    private class CsvMeta
    {
        public string FileName;
        public string[] Headers;
        public string[] FieldTypes; // "int"/"float"/"bool"/"string"/"StatType"
        public string ClassName => MakeSafeTypeName(FileName) + "Row";
    }

    // ─────────────────────────────────────────────────────────────
    // type inference (column scan)
    // ─────────────────────────────────────────────────────────────
    private static string DecideTypeForColumn(DataTable t, int col)
    {
        bool any = false;
        bool allBool = true;
        bool allNumeric = true;
        bool anyFloat = false;

        foreach (DataRow r in t.Rows)
        {
            var o = r[col];
            if (o == null || o == DBNull.Value) continue;

            string s = Clean(o.ToString());
            if (string.IsNullOrEmpty(s) || IsNaToken(s)) continue;

            any = true;

            if (IsBoolToken(s))
            {
                // still OK for allBool
                continue;
            }
            else
            {
                allBool = false;
            }

            string n = NormalizeNumeric(s);
            if (float.TryParse(n, NumberStyles.Float, CultureInfo.InvariantCulture, out _))
            {
                if (!int.TryParse(n, NumberStyles.Integer, CultureInfo.InvariantCulture, out _))
                    anyFloat = true;
            }
            else
            {
                allNumeric = false;
            }
        }

        if (!any) return "string";
        if (allBool && !allNumeric) return "bool";
        if (allNumeric) return anyFloat ? "float" : "int";
        return "string";
    }

    // ─────────────────────────────────────────────────────────────
    // JSON write (keep strings verbatim, empty -> "")
    // ─────────────────────────────────────────────────────────────
    private static void WriteJsonFromDataTable(string jsonPath, DataTable table, string[] headers)
    {
        var rows = new List<Dictionary<string, object>>(table.Rows.Count);

        foreach (DataRow dr in table.Rows)
        {
            var row = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);

            for (int c = 0; c < headers.Length; c++)
            {
                string key = headers[c];
                object val = dr[c];

                if (val == null || val == DBNull.Value)
                {
                    row[key] = ""; // keep column with empty string
                    continue;
                }

                string raw = val.ToString() ?? "";
                string s = Clean(raw);

                if (string.IsNullOrEmpty(s))
                {
                    row[key] = "";
                    continue;
                }

                string norm = NormalizeNumeric(s);

                if (double.TryParse(norm, NumberStyles.Float, CultureInfo.InvariantCulture, out var nd))
                {
                    row[key] = nd;
                }
                else if (bool.TryParse(s, out var nb) || s == "0" || s == "1")
                {
                    row[key] = (s == "1") ? true : (s == "0") ? false : nb;
                }
                else
                {
                    row[key] = raw; // verbatim string (e.g., "Icon/Weapon/1_BrokenSword")
                }
            }

            rows.Add(row);
        }

        var json = MiniJsonWrite(rows);
        Directory.CreateDirectory(Path.GetDirectoryName(jsonPath)!);
        File.WriteAllText(jsonPath, json, new UTF8Encoding(false));
    }

    // ─────────────────────────────────────────────────────────────
    // Row class (unique member names)
    // ─────────────────────────────────────────────────────────────
    private static void GenerateRowClass(CsvMeta m)
    {
        var sb = new StringBuilder(4096);
        sb.AppendLine("// Auto-generated class");
        sb.AppendLine("using System.Collections.Generic;");
        sb.AppendLine();
        sb.AppendLine($"public class {m.ClassName}");
        sb.AppendLine("{");

        var used = new HashSet<string>(StringComparer.Ordinal);
        for (int i = 0; i < m.Headers.Length; i++)
        {
            string member = MakeSafeMemberName(m.Headers[i]);
            int suf = 1;
            string uniq = member;
            while (!used.Add(uniq))
                uniq = member + "_" + (++suf);

            sb.AppendLine($"    public {m.FieldTypes[i]} {uniq};");
        }
        sb.AppendLine("}");

        File.WriteAllText(Path.Combine(OutputScriptPath, m.ClassName + ".cs"), sb.ToString(), new UTF8Encoding(false));
    }

    // ─────────────────────────────────────────────────────────────
    // Registry (loads JSON)
    // ─────────────────────────────────────────────────────────────
    private static void GenerateRegistry(List<CsvMeta> metas)
    {
        var sb = new StringBuilder(65536);
        sb.AppendLine("// Auto-generated registry (loads JSON generated from XLSX)");
        sb.AppendLine("using System;");
        sb.AppendLine("using System.Collections.Generic;");
        sb.AppendLine("using System.Globalization;");
        sb.AppendLine("using UnityEngine;");
        sb.AppendLine();
        sb.AppendLine("public static class GameDataRegistry");
        sb.AppendLine("{");

        foreach (var m in metas)
            sb.AppendLine($"    public static readonly List<{m.ClassName}> {m.FileName}List = new();");

        sb.AppendLine();
        sb.AppendLine("    static int    GetInt   (Dictionary<string, object> m, string k, int def=0)    => m!=null && m.TryGetValue(k, out var v) ? (v is IConvertible ? Convert.ToInt32(v, CultureInfo.InvariantCulture) : def) : def;");
        sb.AppendLine("    static float  GetFloat (Dictionary<string, object> m, string k, float def=0f) => m!=null && m.TryGetValue(k, out var v) ? (v is IConvertible ? Convert.ToSingle(v, CultureInfo.InvariantCulture) : def) : def;");
        sb.AppendLine("    static bool   GetBool  (Dictionary<string, object> m, string k, bool def=false){ if(m==null||!m.TryGetValue(k,out var v)) return def; if(v is bool b) return b; if(v is IConvertible c){ var s=c.ToString(CultureInfo.InvariantCulture); if(bool.TryParse(s,out var bb)) return bb; if(s==\"1\")return true; if(s==\"0\")return false;} return def; }");
        sb.AppendLine("    static string GetString(Dictionary<string, object> m, string k, string def=\"\"){ if(m==null||!m.TryGetValue(k,out var v)||v==null) return def; return v.ToString(); }");
        sb.AppendLine("    static StatType ParseStatType(string s){ if(string.IsNullOrEmpty(s)) return StatType.Unknown; var key=s.Trim().Replace(\" \",\"_\").Replace(\"-\",\"_\"); if(!Enum.TryParse<StatType>(key,true,out var e)) e=StatType.Unknown; return e; }");

        sb.AppendLine();
        sb.AppendLine("    static class MiniJsonLite");
        sb.AppendLine("    {");
        sb.AppendLine("        public static List<Dictionary<string, object>> ParseArray(string json)");
        sb.AppendLine("        {");
        sb.AppendLine("            if (string.IsNullOrEmpty(json)) return null;");
        sb.AppendLine("            int i=0; SkipWs(json, ref i); if(i>=json.Length||json[i]!='[') return null; i++;");
        sb.AppendLine("            var list = new List<Dictionary<string, object>>();");
        sb.AppendLine("            while(true){ SkipWs(json, ref i); if(i>=json.Length) break; if(json[i]==']'){ i++; break; } var obj=ParseObject(json, ref i); if(obj==null) break; list.Add(obj); SkipWs(json, ref i); if(i<json.Length && json[i]==','){ i++; continue; } }");
        sb.AppendLine("            return list;");
        sb.AppendLine("        }");
        sb.AppendLine("        static Dictionary<string, object> ParseObject(string s, ref int i)");
        sb.AppendLine("        {");
        sb.AppendLine("            SkipWs(s, ref i); if(i>=s.Length||s[i]!='{') return null; i++; var d=new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);");
        sb.AppendLine("            while(true){ SkipWs(s, ref i); if(i>=s.Length) break; if(s[i]=='}'){ i++; break; } var key=ParseString(s, ref i); SkipWs(s, ref i); if(i>=s.Length||s[i] != ':') break; i++; var val=ParseValue(s, ref i); d[key]=val; SkipWs(s, ref i); if(i<s.Length && s[i]==','){ i++; continue; } }");
        sb.AppendLine("            return d;");
        sb.AppendLine("        }");
        sb.AppendLine("        static object ParseValue(string s, ref int i)");
        sb.AppendLine("        {");
        sb.AppendLine("            SkipWs(s, ref i); if(i>=s.Length) return null; char c=s[i];");
        sb.AppendLine("            if(c=='\"') return ParseString(s, ref i);");
        sb.AppendLine("            if(c=='{')  return ParseObject(s, ref i);");
        sb.AppendLine("            if(c=='['){ var arr=new List<object>(); i++; while(true){ SkipWs(s, ref i); if(i>=s.Length) break; if(s[i]==']'){ i++; break; } var v=ParseValue(s, ref i); arr.Add(v); SkipWs(s, ref i); if(i<s.Length && s[i]==','){ i++; continue; } } return arr; }");
        sb.AppendLine("            int start=i; while(i<s.Length && \",}]\\t\\r\\n \".IndexOf(s[i])<0) i++; var token=s.Substring(start,i-start);");
        sb.AppendLine("            if(string.Equals(token,\"true\",StringComparison.OrdinalIgnoreCase)) return true;");
        sb.AppendLine("            if(string.Equals(token,\"false\",StringComparison.OrdinalIgnoreCase)) return false;");
        sb.AppendLine("            if(string.Equals(token,\"null\",StringComparison.OrdinalIgnoreCase)) return null;");
        sb.AppendLine("            if(double.TryParse(token, NumberStyles.Float, CultureInfo.InvariantCulture, out var num)) return num;");
        sb.AppendLine("            return token;");
        sb.AppendLine("        }");
        sb.AppendLine("        static string ParseString(string s, ref int i)");
        sb.AppendLine("        {");
        sb.AppendLine("            if(s[i] != '\"') return string.Empty; i++; var sb=new System.Text.StringBuilder();");
        sb.AppendLine("            while(i<s.Length){ char c=s[i++]; if(c=='\"') break; if(c=='\\\\'){ if(i>=s.Length) break; char e=s[i++]; switch(e){ case 'n': sb.Append('\\n'); break; case 'r': break; case 't': sb.Append('\\t'); break; case '\"': sb.Append('\"'); break; case '\\\\': sb.Append('\\\\'); break; default: sb.Append(e); break; } } else sb.Append(c);} return sb.ToString();");
        sb.AppendLine("        }");
        sb.AppendLine("        static void SkipWs(string s, ref int i){ while(i<s.Length){ char c=s[i]; if(c==' '||c=='\\t'||c=='\\n'||c=='\\r') i++; else break; } }");
        sb.AppendLine("    }");

        sb.AppendLine();
        sb.AppendLine("    static GameDataRegistry()");
        sb.AppendLine("    {");
        foreach (var m in metas) sb.AppendLine($"        Load_{m.FileName}();");
        sb.AppendLine("    }");

        sb.AppendLine();
        foreach (var m in metas)
        {
            string key = $"CSVDataJson/{m.FileName}";
            sb.AppendLine($"    static void Load_{m.FileName}()");
            sb.AppendLine("    {");
            sb.AppendLine($"        var ta = Resources.Load<TextAsset>(\"{key}\");");
            sb.AppendLine("        if (ta == null || string.IsNullOrEmpty(ta.text)) { Debug.LogError($\"[Registry] JSON not found: " + key + "\"); return; }");
            sb.AppendLine("        var rows = MiniJsonLite.ParseArray(ta.text);");
            sb.AppendLine("        if (rows == null) { Debug.LogError(\"[Registry] JSON parse failed\"); return; }");
            sb.AppendLine($"        var list = {m.FileName}List; list.Clear();");
            sb.AppendLine("        foreach (var map in rows)");
            sb.AppendLine("        {");
            sb.AppendLine($"            var d = new {m.ClassName}();");

            // map->row assignment
            // keep exact header key lookups (string), but member names are safe (unique) ones used in class
            var usedMembers = new HashSet<string>(StringComparer.Ordinal);
            for (int i = 0; i < m.Headers.Length; i++)
            {
                string h = m.Headers[i];
                string t = m.FieldTypes[i];

                // must compute the exact member name with same uniqueness rule used in GenerateRowClass
                string member = MakeSafeMemberName(h);
                int suf = 1;
                string uniq = member;
                while (!usedMembers.Add(uniq)) // this loop will always pass in registry generation order too
                    uniq = member + "_" + (++suf);

                if (t == "int") sb.AppendLine($"            d.{uniq} = GetInt(map, \"{h}\", 0);");
                else if (t == "float") sb.AppendLine($"            d.{uniq} = GetFloat(map, \"{h}\", 0f);");
                else if (t == "bool") sb.AppendLine($"            d.{uniq} = GetBool(map, \"{h}\", false);");
                else if (t == "StatType") sb.AppendLine($"            d.{uniq} = ParseStatType(GetString(map, \"{h}\", \"\"));");
                else sb.AppendLine($"            d.{uniq} = GetString(map, \"{h}\", \"\");");
            }
            sb.AppendLine("            list.Add(d);");
            sb.AppendLine("        }");
            sb.AppendLine($"        Debug.Log($\"[Registry] {m.FileName} loaded: {{ {m.FileName}List.Count }} rows\");");
            sb.AppendLine("    }");
            sb.AppendLine();
        }

        sb.AppendLine("}");
        File.WriteAllText(RegistryFilePath, sb.ToString(), new UTF8Encoding(false));
    }

    // ─────────────────────────────────────────────────────────────
    // StatType enum
    // ─────────────────────────────────────────────────────────────
    private static void GenerateStatTypeEnum(HashSet<string> rawValues)
    {
        var names = new List<string> { "Unknown" };
        if (rawValues != null)
        {
            foreach (var v in rawValues)
            {
                var id = ToEnumIdentifier(v);
                if (!string.IsNullOrEmpty(id) && !names.Contains(id))
                    names.Add(id);
            }
        }

        var sb = new StringBuilder();
        sb.AppendLine("// Auto-generated enum from XLSX statType values");
        sb.AppendLine("public enum StatType");
        sb.AppendLine("{");
        for (int i = 0; i < names.Count; i++)
            sb.AppendLine(i == 0 ? $"    {names[i]} = 0," : $"    {names[i]},");
        sb.AppendLine("}");
        File.WriteAllText(StatEnumFilePath, sb.ToString(), new UTF8Encoding(false));
    }

    // ─────────────────────────────────────────────────────────────
    // utils
    // ─────────────────────────────────────────────────────────────
    private static string Clean(string s)
        => string.IsNullOrEmpty(s)
           ? string.Empty
           : s.Trim().Trim('\r', '\n', '\t', '\"', ' ')
               .Replace('\u00A0', ' ')
               .Trim();

    private static bool EqualsIgnoreCase(string a, string b)
        => string.Equals(a, b, StringComparison.OrdinalIgnoreCase);

    private static int IndexOfIgnoreCase(string[] arr, string target)
    {
        for (int i = 0; i < arr.Length; i++)
            if (EqualsIgnoreCase(Clean(arr[i]), target)) return i;
        return -1;
    }

    private static string NormalizeNumeric(string s)
    {
        s = Clean(s);
        if (string.IsNullOrEmpty(s)) return s;
        bool neg = s.StartsWith("(") && s.EndsWith(")");
        if (neg) s = s.Substring(1, s.Length - 2);
        s = s.Replace(",", "");
        if (s.EndsWith("%")) s = s.Substring(0, s.Length - 1);
        s = s.Trim();
        if (neg) s = "-" + s;
        return s;
    }

    private static bool IsBoolToken(string s)
    {
        s = Clean(s);
        return s.Equals("true", StringComparison.OrdinalIgnoreCase) ||
               s.Equals("false", StringComparison.OrdinalIgnoreCase) ||
               s == "0" || s == "1";
    }

    private static bool IsNaToken(string s)
    {
        s = Clean(s);
        return s.Equals("NA", StringComparison.OrdinalIgnoreCase) ||
               s.Equals("N/A", StringComparison.OrdinalIgnoreCase) ||
               s.Equals("-", StringComparison.OrdinalIgnoreCase);
    }

    private static string MakeSafeTypeName(string raw)
    {
        raw = Clean(raw);
        var sb = new StringBuilder(raw.Length + 4);
        foreach (var c in raw)
            sb.Append(char.IsLetterOrDigit(c) ? c : '_');
        var id = sb.ToString();
        if (string.IsNullOrEmpty(id)) id = "Sheet";
        if (char.IsDigit(id[0])) id = "_" + id;
        return id;
    }

    private static string MakeSafeMemberName(string raw)
    {
        raw = Clean(raw);
        var sb = new StringBuilder(raw.Length + 4);
        foreach (var c in raw)
            sb.Append(char.IsLetterOrDigit(c) ? c : '_');
        var id = sb.ToString();
        if (string.IsNullOrEmpty(id)) id = "Field";
        if (char.IsDigit(id[0])) id = "_" + id;
        return id;
    }

    private static string ToEnumIdentifier(string raw)
    {
        raw = Clean(raw);
        var sb = new StringBuilder(raw.Length);
        foreach (var c in raw) sb.Append(char.IsLetterOrDigit(c) ? c : '_');
        var id = sb.ToString();
        if (string.IsNullOrEmpty(id)) id = "Unknown";
        if (char.IsDigit(id[0])) id = "_" + id;
        return id;
    }

    private static string MiniJsonWrite(List<Dictionary<string, object>> rows)
    {
        var sb = new StringBuilder(rows.Count * 64);
        sb.Append('[');
        for (int i = 0; i < rows.Count; i++)
        {
            if (i > 0) sb.Append(',');
            WriteDict(sb, rows[i]);
        }
        sb.Append(']');
        return sb.ToString();

        static void WriteDict(StringBuilder sb, Dictionary<string, object> d)
        {
            sb.Append('{');
            int k = 0;
            foreach (var kv in d)
            {
                if (k++ > 0) sb.Append(',');
                WriteString(sb, kv.Key);
                sb.Append(':');
                WriteVal(sb, kv.Value);
            }
            sb.Append('}');
        }
        static void WriteVal(StringBuilder sb, object v)
        {
            if (v == null) { sb.Append("null"); return; }
            switch (v)
            {
                case string s: WriteString(sb, s); break;
                case bool b: sb.Append(b ? "true" : "false"); break;
                case IFormattable f: sb.Append(f.ToString(null, CultureInfo.InvariantCulture)); break;
                default: WriteString(sb, v.ToString()); break;
            }
        }
        static void WriteString(StringBuilder sb, string s)
        {
            sb.Append('"');
            foreach (var c in s)
            {
                if (c == '"' || c == '\\') { sb.Append('\\').Append(c); }
                else if (c == '\n') sb.Append("\\n");
                else if (c == '\r') { /* skip */ }
                else sb.Append(c);
            }
            sb.Append('"');
        }
    }
}
#endif
