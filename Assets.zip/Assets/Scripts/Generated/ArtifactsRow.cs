// Auto-generated class
using System.Collections.Generic;

public class ArtifactsRow
{
    public int ID;
    public string Name;
    public string Desc;
    public string Icon;
    public int costGrowth;
    public int maxLevel;
    public float damageMultiplier;
    public float damageMultipleGrowth;
    public StatType statType;
    public float Value;
    public float valueGrowth;
}
