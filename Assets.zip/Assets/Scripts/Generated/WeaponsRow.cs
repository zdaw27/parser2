// Auto-generated class
using System.Collections.Generic;

public class WeaponsRow
{
    public int ID;
    public string Name;
    public string Desc;
    public int Rank;
    public string specialAbilityType;
    public float specialAbilityValue;
    public int autoAttackDamage;
    public int autoAttackDamageGrowth;
    public int tapDamage;
    public int tapDamageGrowth;
    public int growthCost;
    public int growthCostChange;
}
