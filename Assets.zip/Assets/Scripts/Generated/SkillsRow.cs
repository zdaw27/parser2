// Auto-generated class
using System.Collections.Generic;

public class SkillsRow
{
    public int ID;
    public string Name;
    public string Desc;
    public string Icon;
    public string Type;
    public int Value;
    public float valueGrowth;
    public int coolTime;
    public int duration;
}
