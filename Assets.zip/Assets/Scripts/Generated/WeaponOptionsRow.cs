// Auto-generated class
using System.Collections.Generic;

public class WeaponOptionsRow
{
    public int ID;
    public string Name;
    public StatType statType;
    public float minCommon;
    public float maxCommon;
    public float growthCommon;
    public float minUncommon;
    public float maxUncommon;
    public float growthUncommon;
    public float minRare;
    public float maxRare;
    public float growthRare;
    public float minLegend;
    public float maxLegend;
    public float growthLegend;
    public float minMythic;
    public float maxMythic;
    public float growthMythic;
}
