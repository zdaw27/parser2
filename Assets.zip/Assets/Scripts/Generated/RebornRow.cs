// Auto-generated class
using System.Collections.Generic;

public class RebornRow
{
    public int ID;
    public int Stage;
    public int Treasure;
    public int Fame;
}
