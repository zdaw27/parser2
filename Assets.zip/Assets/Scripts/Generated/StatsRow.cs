// Auto-generated class
using System.Collections.Generic;

public class StatsRow
{
    public int ID;
    public StatType statType;
    public string Desc;
    public string Funtest;
}
