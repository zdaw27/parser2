// Auto-generated class
using System.Collections.Generic;

public class ArtifactCostsRow
{
    public int ID;
    public int ArtifactCount;
    public int TreasureCount;
}
